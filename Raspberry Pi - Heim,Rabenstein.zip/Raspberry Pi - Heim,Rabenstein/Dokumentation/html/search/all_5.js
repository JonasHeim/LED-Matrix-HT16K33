var searchData=
[
  ['isinverted',['isInverted',['../class_main_window.html#a96d737317356b1d65f358bac11d559a0',1,'MainWindow']]]
];
