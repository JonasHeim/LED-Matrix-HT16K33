var searchData=
[
  ['display_5fsetting',['display_setting',['../class_main_window.html#a287ed8a12ac7b57096bcf518c1e97e05',1,'MainWindow']]]
];
