var searchData=
[
  ['zeichenkodierungen',['Zeichenkodierungen',['../group___c_h_a_r_s.html',1,'']]]
];
