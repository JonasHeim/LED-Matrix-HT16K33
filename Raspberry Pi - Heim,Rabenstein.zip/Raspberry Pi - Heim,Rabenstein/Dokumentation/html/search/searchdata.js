var indexSectionsWithContent =
{
  0: "bcdfhilmorsuwz~",
  1: "m",
  2: "u",
  3: "hmru",
  4: "chmo~",
  5: "cdfimru",
  6: "hmwz",
  7: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "groups",
  7: "pages"
};

var indexSectionLabels =
{
  0: "Alle",
  1: "Klassen",
  2: "Namensbereiche",
  3: "Dateien",
  4: "Funktionen",
  5: "Variablen",
  6: "Gruppen",
  7: "Seiten"
};

