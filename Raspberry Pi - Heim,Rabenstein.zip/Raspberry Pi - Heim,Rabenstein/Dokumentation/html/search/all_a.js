var searchData=
[
  ['scroll_5fwait',['SCROLL_WAIT',['../group___w_a_i_t.html#ga8df2efc8800bf97976373fd2634e2e6e',1,'HT16K33.h']]],
  ['scroll_5fwait_5fstill',['SCROLL_WAIT_STILL',['../group___w_a_i_t.html#gadb72bb3c4e59d58d21c01419c405ca7e',1,'HT16K33.h']]]
];
